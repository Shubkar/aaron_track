<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_model extends CI_Model{

	function change_status($id,$status) {
		$data = explode("_", $id);
		$active=0;
		$p=0;
		if($status == 1) { $active=0; } else { $active=1; }
		if($data[0] == "applications") {
			$table = "tr_applications";
			$set = array("status" => $active);
			$where = array("id" => $data[1]);
		} elseif($data[0] == "cmpapps") {
			$table = "cmp_apps";
			$set = array("status" => $active);
			$where = array("id" => $data[1]);
		} elseif($data[0] == "user") {
			$table = "users";
			$set = array("userStatus" => $active);
			$where = array("id" => $data[1]);
		} elseif($data[0] == "category") {
			$table = "cmp_cat";
			$set = array("status" => $active);
			$where = array("id" => $data[1]);
		}
		$this->db->set($set);
		$this->db->where($where);
		$result = $this->db->update($table);
		
		$query_status = ($result == TRUE ? TRUE : FALSE);
		return json_encode(array('success'=>$query_status,'status'=>$active));
	}

	function bkings($status) {
		$this->db->select("C.id as cid,C.firstName,C.lastName,C.mobile,C.mobileAlternate,E.eventListName,E.id as eid,EY.eventTypeName,EY.id as eyid,B.id,B.referenceId,B.possessionDateTime,B.eventDate,B.remarks,B.withLawn,B.packageAmount,B.totalServiceAmount,B.discountAmount,B.advanceAmount,B.balanceAmount,B.ref_user,B.hallAmount,B.hallAmountTax,B.hallAmountTotal,B.status,E.possessionTime,E.possessionEndTime,B.id as bid,B.is_catering,B.is_decoration");
		$this->db->from("bookings B");
		$this->db->join("customer C","C.id = B.customerId");
		$this->db->join("eventslist E","E.id = B.eventListId");
		$this->db->join("eventstypelist EY","EY.id = B.eventTypeId");
		$this->db->where('bookingType','B');
		$this->db->where('bookingStatus','Active');
		$this->db->where('B.status',$status);
		return $this->db->get()->result();
	}

	function download_upcoming_bking() {
		 $get = $this->bkings(1);
	     $temp = array();
			foreach($get as $row) {
			   $total = $row->packageAmount + $row->totalServiceAmount - $row->discountAmount;
			    $temp[] = array(
			        "MM".$row->bid,$row->referenceId,$row->firstName." ".$row->lastName,$row->mobile,$row->mobileAlternate,$row->eventListName,
			      	$row->eventTypeName,date("d-m-Y",strtotime($row->possessionDateTime)),date("d-m-Y",strtotime($row->eventDate)),$row->remarks,$row->withLawn,$row->is_catering,$row->is_decoration,
			        $row->packageAmount,$row->totalServiceAmount,
			        $row->discountAmount,$total,$row->advanceAmount,$row->balanceAmount);
			}
			
	    $file_name = 'Malimanch_Upcoming_Event_Report_'.date("d_m_Y").'.csv'; 
                header("Content-Description: File Transfer"); 
                header("Content-Disposition: attachment; filename=$file_name"); 
                header("Content-Type: application/csv;");
                $file = fopen('php://output', 'w');
                $header = array("Booking ID#","Ref#","Customer","Mobile","Alternate Mobile","Event","Event Type","Possesion Date","Event Date","Remarks","Lawn","Catering","Decoration","Basic Amount","Total Service Amount","Discount Amount","Total Amount","Paid Amount","Balance Amount"); 
                fputcsv($file, $header);
                foreach ($temp as $value) {
                   fputcsv($file, $value);
                }
                fclose($file); 
                exit(1);
	}

	function download_completed_events() {
		$get = $this->bkings(2);
		  $temp = array();
			foreach($get as $row) {
			   $total = $row->packageAmount+$row->totalServiceAmount-$row->discountAmount;
			    $temp[] = array(
			        "MM".$row->bid,$row->referenceId,$row->firstName." ".$row->lastName,$row->mobile,$row->mobileAlternate,$row->eventListName,
			      	$row->eventTypeName,date("d-m-Y",strtotime($row->possessionDateTime)),date("d-m-Y",strtotime($row->eventDate)),$row->remarks,$row->withLawn,$row->is_catering,$row->is_decoration,
			        $row->packageAmount,$row->totalServiceAmount,
			        $row->discountAmount,$total,$row->advanceAmount,$row->balanceAmount);
			}
			
	    $file_name = 'Malimanch_Completed_Event_Report_'.date("d_m_Y").'.csv'; 
                header("Content-Description: File Transfer"); 
                header("Content-Disposition: attachment; filename=$file_name"); 
                header("Content-Type: application/csv;");
                $file = fopen('php://output', 'w');
                $header = array("Booking ID#","Ref#","Customer","Mobile","Alternate Mobile","Event","Event Type","Possesion Date","Event Date","Remarks","Lawn","Catering","Decoration","Basic Amount","Total Service Amount","Discount Amount","Total Amount","Paid Amount","Balance Amount"); 
                fputcsv($file, $header);
                foreach ($temp as $value) {
                   fputcsv($file, $value);
                }
                fclose($file); 
                exit(1);
	}

	function download_cancelled_events() {
				$get = $this->bkings(3);
		  $temp = array();
			foreach($get as $row) {
			   $total = $row->packageAmount+$row->totalServiceAmount-$row->discountAmount;
			    $temp[] = array(
			        "MM".$row->bid,$row->referenceId,$row->firstName." ".$row->lastName,$row->mobile,$row->mobileAlternate,$row->eventListName,
			      	$row->eventTypeName,date("d-m-Y",strtotime($row->possessionDateTime)),date("d-m-Y",strtotime($row->eventDate)),$row->remarks,$row->withLawn,$row->is_catering,$row->is_decoration,
			        $row->packageAmount,$row->totalServiceAmount,
			        $row->discountAmount,$total,$row->advanceAmount,$row->balanceAmount);
			}
			
	    $file_name = 'Malimanch_Cancelled_Events_Report_'.date("d_m_Y").'.csv'; 
                header("Content-Description: File Transfer"); 
                header("Content-Disposition: attachment; filename=$file_name"); 
                header("Content-Type: application/csv;");
                $file = fopen('php://output', 'w');
                $header = array("Booking ID#","Ref#","Customer","Mobile","Alternate Mobile","Event","Event Type","Possesion Date","Event Date","Remarks","Lawn","Catering","Decoration","Basic Amount","Total Service Amount","Discount Amount","Total Amount","Paid Amount","Balance Amount"); 
                fputcsv($file, $header);
                foreach ($temp as $value) {
                   fputcsv($file, $value);
                }
                fclose($file); 
                exit(1);
	}

	function get_count($table, $where) {
		return $this->db->get_where($table, $where)->num_rows();
	}

	function get_total_sum() {
		$this->db->select_sum('balanceAmount');
		$result = $this->db->get_where('bookings',array('bookingStatus' => 'Active','bookingType' => 'B','status' => 1,'possessionDateTime >=' => date("Y-m-d")))->row();
		// echo $this->db->last_query(); die();
	/*	$total = array();
		foreach($result as $row) {
			$total[] = $row->packageAmount + $row->totalServiceAmount - $row->discountAmount;
		}*/
		return $result->balanceAmount;
	}
	
	function get_total_balance_completed() {
	    $this->db->select_sum('balanceAmount');
		$result = $this->db->get_where('bookings',array('bookingStatus' => 'Active','bookingType' => 'B','status' => 2))->row();
		return $result->balanceAmount;
	}

	function map_ids() {
		$this->db->select('id,evtid');
		$result = $this->db->get('eventstypelist')->result();

		foreach($result as $row) {
			$this->db->update('bookings',array('eventTypeId' => $row->id,'eyid' => 1),array('eventTypeId' => $row->evtid,'eyid' => 0));
		}
	}
	
	function send_bk_sms() {
		$mobile = $this->input->post('mobile');
		$message = $this->input->post('sms_msg');
		$cid = $this->input->post('cid');
		$this->db->select('mobileAlternate');
		$m = $this->db->get_where('customer',array("id" => $cid));
		if($m->num_rows() > 0){
		    $fetch = $m->row();
		    $mobile = $mobile.",91".$fetch->mobileAlternate.",918884111636";
		} else {
		    $mobile = $mobile.",918884111636";
		}
		return $this->send_sms($mobile,$message);
	}
	
	function all_cust_sms_send() {
	    $message = $this->input->post('sms_msg');
	    
	    $this->db->select('mobile,mobileAlternate');
	    $this->db->group_by('mobile,mobileAlternate');
	    $result = $this->db->get('customer')->result();
	    $tmp = array();
	    foreach($result as $row) {
	        $tmp[] = $row->mobile;
	        $tmp[] = $row->mobileAlternate;
	    }
	    $mob = implode(",",$tmp);
	    return $this->send_sms($mob,$message);
	}
	
	function send_sms($mobile,$message) {
	  $mobileNumber = urlencode($mobile);
	  $message = urlencode($message);
	  $url = "https://apibulksms.way2mint.com/pushsms?username=malimanch&password=tbHN-24-&from=MMANCH&to=91".$mobileNumber."&text=".$message;  
      $ch = curl_init();
      curl_setopt_array($ch, array(CURLOPT_URL => $url, CURLOPT_RETURNTRANSFER => true));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		$output = curl_exec($ch);
		$info = curl_getinfo($ch);
		$messageStatus = "";
		if (curl_errno($ch))  {
			$messageStatus .= "<h2>Curl not executed.........<h2>";
			$messageStatus .= "Error...= ". curl_error($ch)."<br/>";
			$messageStatus .= "<h4>Message = ". $output.";<h4><br/>";
			return $messageStatus;
		} else {
			return 200;
		}
	}
	
	function fecth_event_date_detail($date) {
		$this->db->select("C.firstName,C.lastName,E.eventListName,B.possessionDateTime,B.eventDate,EY.eventTypeName,EY.colorCode,E.id,E.eventListName,B.eventListId,B.balanceAmount,B.id as bid,B.withLawn,B.is_catering,B.is_decoration");
		$this->db->from("bookings B");
		$this->db->join("customer C","C.id = B.customerId");
		$this->db->join("eventslist E","E.id = B.eventListId");
		$this->db->join("eventstypelist EY","EY.id = B.eventTypeId");
		$this->db->where('bookingStatus','Active');
		$this->db->where('B.possessionDateTime',$date);
		$this->db->where_in('B.status',array(1,2));
		$this->db->where('bookingType','B');
		$this->db->order_By('possessionDateTime');
		return $this->db->get();
	}

function prev_month_last_date($month,$year) {
		if($month == 1) {
			$month = 12;
			$year--;
		} else {
			$month--;
		}
		$month = date('m', strtotime($month));
		$year = date('m', strtotime($year));
		return cal_days_in_month(CAL_GREGORIAN,$month,$year);
	}

	function prev_month_year_date($month,$year) {
		if($month == 1) {
			$month = 12;
			$year--;
		} else {
			$month--;
		}
		return array("month" => $month,"year" => $year);
	}

	function next_month_year_date($month,$year) {
		if($month == 1) {
			$month = 12;
			$year++;
		} else {
			$month++;
		}
		return array("month" => $month,"year" => $year);
	}

	function draw_calendar($month,$year){
		/* draw table */
		$calendar = '<table class="calendar">';

		/* table headings */
		$headings = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
		$calendar.= '<tr class="calendar-row"><td class="calendar-day-head ftsz" style="width: 150px;">'.implode('</td><td class="calendar-day-head ftsz" style="width: 150px;">',$headings).'</td></tr>';
		/* days and weeks vars now ... */
		$month = intval($month);
		$year = intval($year);
		$running_day = date('w',mktime(0,0,0,$month,1,$year));
		$days_in_month = date('t',mktime(0,0,0,$month,1,$year));
		$lmd = $this->prev_month_last_date($month,$year);
		$last_my = $this->prev_month_year_date($month,$year);
		$next_my = $this->next_month_year_date($month,$year);
		$days_in_this_week = 1;
		$day_counter = 0;
		$dates_array = array();

		/* row for week one */
		$calendar.= '<tr class="calendar-row">';
		$lmd = $lmd - $running_day;
		$lmd++;
		/* print "blank" days until the first of the current week */
		for($x = 0; $x < $running_day; $x++):
			$ckc = $this->check_holiday($last_my['year']."-".$last_my['month']."-".$lmd);
			if($ckc != "NA")
				$calendar.= '<td class="calendar-day-np"><div class="day-number-holiday" data-bs-toggle="tooltip" data-bs-placement="right" title="'.$ckc.'">'.$lmd.'</div>';
			else
				$calendar.= '<td class="calendar-day-np"><div class="day-number">'.$lmd.'</div>';
			$tmp_date = $last_my['year']."-".$last_my['month']."-".$lmd;
				$bk = $this->fecth_event_date_detail($tmp_date);
				// echo $this->db->last_query();
				if($bk->num_rows() > 0) {
				    $calendar.= '<div style="margin-left:-4%;">';
				    $gap = 0;
					foreach($bk->result() as $fetch) {
    					$title = ucfirst($fetch->firstName).' '.ucfirst($fetch->lastName).' ';
    					$title .= "Bal amt: ".$fetch->balanceAmount;
    					 $link = '#';
    					if($this->session->userdata('aD_User_type') == "A" ||$this->session->userdata('aD_User_type') == "M") {
    					    $link = base_url('edit_booking/'.$fetch->bid);
    					} 
    					$name = $fetch->firstName.' '.$fetch->lastName;
    					
    					$border = '';
    					if($fetch->withLawn == "Y" || $fetch->is_catering == "Y" || $fetch->is_decoration == "Y") {
    					    $border = "border_event_Calendar";
    					}
    					$text_class = ""; 

    					$calendar.= '<div class="text-wrap '.$border;
    						if($fetch->eventListId == 3) {	
    							 $calendar.= ' pre_wedd_cal';
    							 $text_class = "calendar_name_ft_pre_wedding";
    						} elseif($fetch->eventListId == 2) {
    							$calendar.= ' noon_cal';
    							$text_class = "calendar_name_ft_noon";
    						} elseif($fetch->eventListId == 5) {
    							$calendar.= ' night_calendar';
    							$text_class = "calendar_name_ft_night";
    						} elseif($fetch->eventListId == 1) {
    							$calendar.= ' day_night_cal';
    							$text_class = "calendar_name_ft_day_night";
    						}

    					$calendar.= ' " style="background-color:'.$fetch->colorCode.'  ;">
    								<a title="'.$title.'" href="'.$link.'" class="text-decoration-none text-dark text-capitalize '.$text_class.' fw-bold">&nbsp;&nbsp;&nbsp;'.$name.'
    								</a>
    							</div>';
    						
					}
					$calendar.= '</div>';
				}
				$calendar.= '</td>';
			$lmd++;
			$days_in_this_week++;
		endfor;
        $mdc = $dtnom = $gap_pre = 0;
		/* keep going with days.... */
		for($list_day = 1; $list_day <= $days_in_month; $list_day++):
			$calendar.= '<td class="calendar-day ">';
			        $ckc = $this->check_holiday($year."-".$month."-".$list_day);
				if($ckc != "NA") {
					if(date('d') == $list_day && date('m') == $month && date('Y') == $year)
						$calendar.= '<div class="day-number-holiday-active" data-bs-toggle="tooltip" data-bs-placement="right" title="'.$ckc.'">'.$list_day.'</div>';
					else
						$calendar.= '<div class="day-number-holiday" data-bs-toggle="tooltip" data-bs-placement="right" title="'.$ckc.'">'.$list_day.'</div>';
				} else {
					if(date('d') == $list_day && date('m') == $month && date('Y') == $year)
						$calendar.= '<div class="day-number-active">'.$list_day.'</div>';
					else
						$calendar.= '<div class="day-number">'.$list_day.'</div>';
				}

				$tmp_date = $year."-".$month."-".$list_day;
				$bk = $this->fecth_event_date_detail($tmp_date);
				// echo $this->db->last_query();
				if($bk->num_rows() > 0) {
				    $calendar.= '<div style="margin-left:-4%;">';
				    $gap = 0;
					foreach($bk->result() as $fetch) {
    					$title = ucfirst($fetch->firstName).' '.ucfirst($fetch->lastName).' ';
    					$title .= "Bal amt: ".$fetch->balanceAmount;
    					 $link = '#';
    					if($this->session->userdata('aD_User_type') == "A" ||$this->session->userdata('aD_User_type') == "M") {
    					    $link = base_url('edit_booking/'.$fetch->bid);
    					} 
    					$name = $fetch->firstName.' '.$fetch->lastName;
    					
    					$border = '';
    					if($fetch->withLawn == "Y" || $fetch->is_catering == "Y" || $fetch->is_decoration == "Y") {
    					    $border = "border_event_Calendar";
    					}
    						
    					$text_class = ""; 

    					$calendar.= '<div class="text-wrap  '.$border;
    						if($fetch->eventListId == 3) {	
    							 $calendar.= ' pre_wedd_cal';
    							 $text_class = "calendar_name_ft_pre_wedding";
    						} elseif($fetch->eventListId == 2) {
    							$calendar.= ' noon_cal';
    							$text_class = "calendar_name_ft_noon";
    						} elseif($fetch->eventListId == 5) {
    							$calendar.= ' night_calendar';
    							$text_class = "calendar_name_ft_night";
    						} elseif($fetch->eventListId == 1) {
    							$calendar.= ' day_night_cal';
    							$text_class = "calendar_name_ft_day_night";
    						}

    					$calendar.= ' " style="background-color:'.$fetch->colorCode.'  ;">
    								<a title="'.$title.'" href="'.$link.'" class="text-decoration-none text-dark text-capitalize '.$text_class.' fw-bold">&nbsp;&nbsp;&nbsp;'.$name.'
    								</a>
    							</div>';
    						
					}
					$calendar.= '</div>';
				}
			$calendar.= '</td>';
			if($running_day == 6):
				$calendar.= '</tr>';
				if(($day_counter+1) != $days_in_month):
					$calendar.= '<tr class="calendar-row">';
				endif;
				$running_day = -1;
				$days_in_this_week = 0;
			endif;
			$days_in_this_week++; $running_day++; $day_counter++;
		endfor;

		/* finish the rest of the days in the week */
		if($days_in_this_week < 8):
			for($x = 1; $x <= (8 - $days_in_this_week); $x++):
				$ckc = $this->check_holiday($next_my['year']."-".$next_my['month']."-".$x);
				if($ckc != "NA") {
					$calendar.= '<td class="calendar-day-np"><div class="day-number-holiday" data-bs-toggle="tooltip" data-bs-placement="right" title="'.$ckc.'">'.$x.'</div>';
				} else {
					$calendar.= '<td class="calendar-day-np"><div class="day-number">'.$x.'</div>';
				}
				
				$tmp_date = $next_my['year']."-".$next_my['month']."-".$x;
				$bk = $this->fecth_event_date_detail($tmp_date);
				// echo $this->db->last_query();
				if($bk->num_rows() > 0) {
				    $calendar.= '<div style="margin-left:-4%;">';
				    $gap = 0;
					foreach($bk->result() as $fetch) {
    					$title = ucfirst($fetch->firstName).' '.ucfirst($fetch->lastName).' ';
    					$title .= "Bal amt: ".$fetch->balanceAmount;
    					 $link = '#';
    					if($this->session->userdata('aD_User_type') == "A" ||$this->session->userdata('aD_User_type') == "M") {
    					    $link = base_url('edit_booking/'.$fetch->bid);
    					} 
    					$name = $fetch->firstName.' '.$fetch->lastName;
    					
    					$border = '';
    					if($fetch->withLawn == "Y" || $fetch->is_catering == "Y" || $fetch->is_decoration == "Y") {
    					    $border = "border_event_Calendar";
    					}

    						$text_class = ""; 

    					$calendar.= '<div class="text-wrap '.$border;
    						if($fetch->eventListId == 3) {	
    							 $calendar.= ' pre_wedd_cal';
    							 $text_class = "calendar_name_ft_pre_wedding";
    						} elseif($fetch->eventListId == 2) {
    							$calendar.= ' noon_cal';
    							$text_class = "calendar_name_ft_noon";
    						} elseif($fetch->eventListId == 5) {
    							$calendar.= ' night_calendar';
    							$text_class = "calendar_name_ft_night";
    						} elseif($fetch->eventListId == 1) {
    							$calendar.= ' day_night_cal';
    							$text_class = "calendar_name_ft_day_night";
    						}

    					$calendar.= ' " style="background-color:'.$fetch->colorCode.'  ;">
    								<a title="'.$title.'" href="'.$link.'" class="text-decoration-none text-dark text-capitalize '.$text_class.' fw-bold">&nbsp;&nbsp;&nbsp;'.$name.'
    								</a>
    							</div>';
    						
					}
					$calendar.= '</div>';
				}
				$calendar.= '</td>';
			endfor;
		endif;

		/* final row */
		$calendar.= '</tr>';

		/* end the table */
		$calendar.= '</table>';
		
		/* all done, return result */
		return $calendar;
	}

	function check_holiday($date) {
		$date = date("Y-m-d",strtotime($date));
		$res = $this->db->get_where("holidays",array("holidate" => $date));
		if($res->num_rows() > 0) {
			$fetch = $res->row();
			return $fetch->holiday;
		} else {
			return "NA";
		}
	}
}
?>