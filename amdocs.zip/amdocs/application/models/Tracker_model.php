<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tracker_model extends CI_Model{

	function fetch_data($table,$where,$select) {
		$this->db->select($select);
		$this->db->where($where);
		return $this->db->get($table);
	}

	function get_tracker_data() {
		$this->db->select('C.*,C.id as cid,A.id,A.name as app_name,U.id,U.loginName');
		$this->db->from('tracker_dt C');
		$this->db->join('tr_applications A','A.id = C.application');
		$this->db->join('users U','U.id = C.names');
		$this->db->where('C.delete_stat','N');
		$result = $this->db->get()->result();

		$n=1; $count=0;
		$output = array();
		foreach($result as $row) :

			$output[] = array(
				'sl' => $n,
				'date' => $row->date,
				'application' => $row->app_name,
				'order_no' => $row->order_num,
				'order_desc' => $row->order_type,
	            'issue_desc' => $row->Issue_desc,
	            'app_ta' => $row->application_t,
	            'reported_date' => $row->reported_date,
	            'status' => $row->status,
	            'name' => $row->loginName,
	            'remark' => $row->remark,
	            'Action' => '<button class="btn btn-dark" type="button" data-bs-toggle="modal" data-bs-target="#addrecordsmodal" data-id="'.$row->cid.'" data-date="'.$row->date.'" data-application="'.$row->app_name.'" data-order_no="'.$row->order_num.'" data-order_desc="'.$row->order_type.'" data-issue_desc="'.$row->Issue_desc.'" data-app_ta="'.$row->application_t.'" data-reported_date="'.$row->reported_date.'" data-status="'.$row->status.'" data-name="'.$row->loginName.'" data-remark="'.$row->remark.'" ><i class="fa fa fa-edit" aria-hidden="true"></i></button>
	            	<button class="btn btn-dark m-1" type="button" data-bs-toggle="modal" data-bs-target="#delete_record_modal" data-id="'.$row->cid.'" title="Delete Data"><i class="fas fa-trash-alt"></i></button>
	            ',
			);
	            $n++; $count++;
        endforeach;
        if($count == 0) return json_encode(array('Data'=>'')); 
        else return json_encode($output);
        // <button class="btn btn-dark" type="button" data-bs-toggle="modal" data-bs-target="#delete_record_modal" data-id="'.$row->id.'" ><i class="fas fa-trash-alt"></i></button>
	}

	function get_compliance_data() {
		$this->db->select('cl.*,cl.id as clid,A.id as aid,A.motsid,A.app_name,S.id,S.category,U.id,U.loginName');
		$this->db->from('compilance_dt cl');
		$this->db->join('cmp_apps A','A.id = cl.motsid');
		$this->db->join('cmp_cat S','S.id = cl.category');
		$this->db->join('users U','U.id = cl.names');
		$this->db->where('cl.delete_stat','N');
		$result = $this->db->get()->result();
		$n=1; $count=0;
		$output = array();
		foreach($result as $row) :

			$output[] = array(
				'sl' => $n,
				'date' => $row->date,
				'motsid' => $row->motsid,
				'application' => $row->app_name,
				'application_ta' => $row->application_t,
	            'category' => $row->category,
	            'task_desc' => $row->task_desc,
	            'no_of_impact' => $row->no_of_impacty,
	            'activity_done' => $row->activity_done,
	            'ticket_no' => $row->ticket_owner,
	            'user' => $row->loginName,
	            'Action' => '<button class="btn btn-dark" type="button" data-bs-toggle="modal" data-bs-target="#addrecordscmpmodal" data-id="'.$row->clid.'" data-date="'.$row->date.'" data-motsid="'.$row->motsid.'" data-application="'.$row->app_name.'" data-category="'.$row->category.'" data-no_of_impacty="'.$row->no_of_impacty.'" data-task_desc="'.$row->task_desc.'" data-app_ta="'.$row->application_t.'" data-activity_done="'.$row->activity_done.'" data-ticket_no="'.$row->ticket_owner.'" data-name="'.$row->names.'" ><i class="fa fa fa-edit" aria-hidden="true"></i></button>
	            	<button class="btn btn-dark m-1" type="button" data-bs-toggle="modal" data-bs-target="#delete_comprecord_modal" data-id="'.$row->clid.'" title="Delete Data"><i class="fas fa-trash-alt"></i></button>
	            ',
			);
	            $n++; $count++;
        endforeach;
        if($count == 0) return json_encode(array('Data'=>'')); 
        else return json_encode($output);
        // <button class="btn btn-dark" type="button" data-bs-toggle="modal" data-bs-target="#delete_comprecord_modal" data-id="'.$row->id.'" ><i class="fas fa-trash-alt"></i></button>
	}

	function manage_tracker() {
		$data = array(
					'date' => $this->input->post('date'),
					'application' => $this->input->post('application'),
					'order_num' => $this->input->post('order_num'),
					'order_type' => $this->input->post('order_type'),
					'Issue_desc' => $this->input->post('Issue_desc'),
					'application_t' => $this->input->post('application_t'),
					'reported_date' => $this->input->post('reported_date'),
					'status' => $this->input->post('status'),
					'names' => $this->input->post('names'),
					'remark' => $this->input->post('remark')
				);

		if(empty($this->input->post('id'))) {
			$this->db->insert('tracker_dt',$data);
			$er_ct = $this->db->error(); 
			if($er_ct['code'] == 0) {
				return json_encode(array('success' => "200",'msg' => "Record Added.")); 
			} else {
				return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
			}
		} else {
			$this->db->update('tracker_dt',$data,array('id' => $this->input->post('id')));
			$er_ct = $this->db->error(); 
			if($er_ct['code'] == 0) {
				return json_encode(array('success' => "200",'msg' => "Record Updated."));
			} else {
				return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
			}
		}
	}

	function delete_tracker() {
		$id = $this->input->post('id');
		$this->db->update('tracker_dt',array("delete_stat" => 'Y'),array('id' => $id));
		$er_ct = $this->db->error(); 
		if($er_ct['code'] == 0) {
			return json_encode(array('success' => "200",'msg' => "Record Deleted.")); 
		} else {
			return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
		}
	}

	function delete_compliance() {
		$id = $this->input->post('id');
		$this->db->update('compilance_dt',array("delete_stat" => 'Y'),array('id' => $id));
		$er_ct = $this->db->error(); 
		if($er_ct['code'] == 0) {
			return json_encode(array('success' => "200",'msg' => "Record Deleted.")); 
		} else {
			return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
		}
	}

	function fetch_motsid_app() {
		$id = $this->input->post("id");
		$this->db->select("app_name");
		$fetch = $this->db->get_where("cmp_apps",array("id" => $id));
		if($fetch->num_rows() > 0) {
			$get = $fetch->row();
			return json_encode(array('success' => "200",'val' => $get->app_name)); 
		} else {
			return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
		}
	}

	function manage_compliance() {
		$data = array(
					'date' => $this->input->post('date'),
					'motsid' => $this->input->post('motsid'),
					'category' => $this->input->post('category'),
					'no_of_impacty' => $this->input->post('no_of_impact'),
					'task_desc' => $this->input->post('task_desc'),
					'application_t' => $this->input->post('application_t'),
					'activity_done' => $this->input->post('activity_done'),
					'ticket_owner' => $this->input->post('ticket_no'),
					'names' => $this->input->post('names')
				);
		if(empty($this->input->post('id'))) {
			$this->db->insert('compilance_dt',$data);
			$er_ct = $this->db->error(); 
			if($er_ct['code'] == 0) {
				return json_encode(array('success' => "200",'msg' => "Record Added.")); 
			} else {
				return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
			}
		} else {
			$this->db->update('compilance_dt',$data,array('id' => $this->input->post('id')));
			$er_ct = $this->db->error(); 
			if($er_ct['code'] == 0) {
				return json_encode(array('success' => "200",'msg' => "Record Updated."));
			} else {
				return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
			}
		}
	}

}
?>