<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model{

	function validate_user() {
		$user_name = $this->input->post('mali_username');
	    $password = $this->input->post('mali_password');

	    $this->db->escape($user_name);
	    $this->db->where('userName',$user_name);
		$result = $this->db->get('users');
	        
        $row = $result->row();
        $total_count = $result->num_rows();
			if ($total_count == 1 && $row->userStatus == 1) {
	            $hash = $row->password;
	            if (password_verify($password, $hash)) {
	            	$session_data = array(
						'aD_min_id' => $row->id,
						'aD_min_NamE' => $row->loginName,
						'aD_minuser_NamE' => $row->userName,
						'aD_User_type' => $row->userType,
						'aD_min_LoGGedIn' => TRUE
					);
				    $this->session->set_userdata($session_data);
					return 200;
				} else return "Invalid Password";
	        } else return "Invalid Users";
	}
	
	function change_password() {
		$this->db->update("users",array("password" => password_hash($this->input->post('password'), PASSWORD_DEFAULT)),array("id" => $this->session->userdata('aD_min_id')));
		$er_ct = $this->db->error(); 
			if($er_ct['code'] == 0) {
				return json_encode(array('success' => "200",'msg' => "Password Updated."));
			} else {
				return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
			}
	}

}

?>