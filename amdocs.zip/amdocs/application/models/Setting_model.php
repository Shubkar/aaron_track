<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting_model extends CI_Model{

	function fetch_application() {
		$result = $this->db->get("tr_applications")->result();
		$n=1; $count=0;
		$output = array();
		foreach($result as $row) :
	        $switch = '<div class="form-check form-switch">
                        <input class="form-check-input chkbx" type="checkbox" id="applications_'.$row->id.'" '; if($row->status == 1) { $switch .= 'checked '; } $switch .= 'value="'.$row->status.'" />
                      </div>';
			$output[] = array(
				'sl' => $n,
				'application' => $row->name,
				'status' => $switch,
	            'buttons' => '<button class="btn btn-dark" type="button" data-bs-toggle="modal" data-bs-target="#addApplication" data-id="'.$row->id.'" data-name="'.$row->name.'"><i class="fa fa fa-edit" aria-hidden="true"></i></button>'           
			);

	            $n++; $count++;
        endforeach;
        if($count == 0) return json_encode(array('Data'=>'')); 
        else return json_encode($output);
	}

	function fetch_category() {
		$result = $this->db->get("cmp_cat")->result();
		$n=1; $count=0;
		$output = array();
		foreach($result as $row) :
	        $switch = '<div class="form-check form-switch">
                        <input class="form-check-input chkbx" type="checkbox" id="category_'.$row->id.'" '; if($row->status == 1) { $switch .= 'checked '; } $switch .= 'value="'.$row->status.'" />
                      </div>';
			$output[] = array(
				'sl' => $n,
				'name' => $row->category,
				'status' => $switch,
	            'buttons' => '<button class="btn btn-dark" type="button" data-bs-toggle="modal" data-bs-target="#addcategory" data-id="'.$row->id.'" data-name="'.$row->category.'"><i class="fa fa fa-edit" aria-hidden="true"></i></button>'           
			);

	            $n++; $count++;
        endforeach;
        if($count == 0) return json_encode(array('Data'=>'')); 
        else return json_encode($output);
	}

	function fetch_motsid_app() {
		$result = $this->db->get("cmp_apps")->result();
		$n=1; $count=0;
		$output = array();
		foreach($result as $row) :
			$switch = '<div class="form-check form-switch">
                        <input class="form-check-input chkbx" type="checkbox" id="cmpapps_'.$row->id.'" '; if($row->status == 1) { $switch .= 'checked '; } $switch .= 'value="'.$row->status.'" />
                      </div>';
			$output[] = array(
				'sl' => $n,
				'motsid' => $row->motsid,
				'appname' => $row->app_name,
				'status' => $switch,
	            'buttons' => '<button class="btn btn-dark" type="button" data-bs-toggle="modal" data-bs-target="#addmotisd" data-id="'.$row->id.'" data-motsid="'.$row->motsid.'" data-appname="'.$row->app_name.'"><i class="fa fa fa-edit" aria-hidden="true"></i></button>'           
			);

	            $n++; $count++;
        endforeach;
        if($count == 0) echo json_encode(array('Data'=>'')); 
        else echo json_encode($output);
	}

	function fetch_users() {
		$result = $this->db->get_where("users",array("delete_stat" => 'N'))->result();
		$n=1; $count=0;
		$output = array();
		foreach($result as $row) :

			$switch = '<div class="form-check form-switch">
                        <input class="form-check-input chkbx" type="checkbox" id="user_'.$row->id.'" '; if($row->userStatus == 1) { $switch .= 'checked '; } $switch .= 'value="'.$row->userStatus.'" />
                      </div>';
                      $ut = "";
            if($row->userType == "A") {
            	$ut = "Admin";
            } elseif($row->userType == "M") {
            	$ut = "Manager";
            } elseif($row->userType == "S") {
            	$ut = "Supervisor";
            }
			$output[] = array(
				'sl' => $n,
				'loginName' => $row->loginName,
				'username' => $row->userName,
				'mobile' => $row->mobile,
				'email' => $row->emailId,
				'register_on' => date("d-m-Y",strtotime($row->created_at)),
				'status' => $switch,
	            'buttons' => '<button class="btn btn-dark m-1" type="button" data-bs-toggle="modal" data-bs-target="#editusersModal" data-id="'.$row->id.'" data-ln="'.$row->loginName.'" data-username="'.$row->userName.'" data-mobile="'.$row->mobile.'" data-email="'.$row->emailId.'" data-usertype="'.$row->userType.'" title="Edit Profile"><i class="fa fa fa-edit" aria-hidden="true"></i></button><button class="btn btn-dark m-1" type="button" data-bs-toggle="modal" data-bs-target="#change_user_password" data-id="'.$row->id.'" data-loginName="'.$row->userName.'" title="Change Password"><i class="fas fa-key"></i></button><button class="btn btn-dark m-1" type="button" data-bs-toggle="modal" data-bs-target="#delete_user_modal" data-id="'.$row->id.'" data-name="'.$row->userName.'" title="Delete User"><i class="fas fa-trash-alt"></i></button>'           
			);

	            $n++; $count++;
        endforeach;
        if($count == 0) echo json_encode(array('Data'=>'')); 
        else echo json_encode($output);
	}


	function count_result($table,$where) {
		$this->db->where($where);
		return $this->db->count_all_results($table);
	}

	function manage_motsid_app() {
		$motsid = $this->input->post('motsid');
		$appname = $this->input->post('appname');
		$ct = $this->count_result("cmp_apps",array("motsid" => $motsid,"app_name" => $appname));
		if(empty($this->input->post('id'))) {
			if($ct == 0) {
				$data = array(
					'motsid' => $motsid,
					'app_name' => $appname
				);
				$this->db->insert('cmp_apps',$data);
				$er_ct = $this->db->error(); 
				if($er_ct['code'] == 0) {
					return json_encode(array('success' => "200",'msg' => "MOTSID Added.")); 
				} else {
					return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
				}
			} else {
				return json_encode(array('success' => "0",'msg' => "MOTSID already exist."));
			}
		} else {
			if($ct == 0 || $ct == 1) {
				$data = array(
					'motsid' => $motsid,
					'app_name' => $appname
				);
				$this->db->update('cmp_apps',$data,array('id' => $this->input->post('id')));
				$er_ct = $this->db->error(); 
				if($er_ct['code'] == 0) {
					return json_encode(array('success' => "200",'msg' => "MOTSID Updated."));
				} else {
					return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
				}
			} else {
				return json_encode(array('success' => "0",'msg' => "MOTSID already exist."));
			}
		}
	}

	function manage_application() {
		$appname = $this->input->post('appname');
		$ct = $this->count_result("tr_applications",array("name" => $appname));
		if(empty($this->input->post('id'))) {
			if($ct == 0) {
				$data = array(
					'name' => $appname
				);
				$this->db->insert('tr_applications',$data);
				$er_ct = $this->db->error(); 
				if($er_ct['code'] == 0) {
					return json_encode(array('success' => "200",'msg' => "Application Added.")); 
				} else {
					return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
				}
			} else {
				return json_encode(array('success' => "0",'msg' => "Application already exist."));
			}
		} else {
			if($ct == 0) {
				$data = array(
					'name' => $appname
				);
				$this->db->update('tr_applications',$data,array('id' => $this->input->post('id')));
				$er_ct = $this->db->error(); 
				if($er_ct['code'] == 0) {
					return json_encode(array('success' => "200",'msg' => "Application Updated."));
				} else {
					return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
				}
			} else {
				return json_encode(array('success' => "0",'msg' => "Application already exist."));
			}
		}
	}

	function manage_category() {
		$category = $this->input->post('category');
		$ct = $this->count_result("cmp_cat",array("category" => $category));
		if(empty($this->input->post('id'))) {
			if($ct == 0) {
				$data = array(
					'category' => $category
				);
				$this->db->insert('cmp_cat',$data);
				$er_ct = $this->db->error(); 
				if($er_ct['code'] == 0) {
					return json_encode(array('success' => "200",'msg' => "Category Added.")); 
				} else {
					return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
				}
			} else {
				return json_encode(array('success' => "0",'msg' => "Category already exist."));
			}
		} else {
			if($ct == 0) {
				$data = array(
					'category' => $category
				);
				$this->db->update('cmp_cat',$data,array('id' => $this->input->post('id')));
				$er_ct = $this->db->error(); 
				if($er_ct['code'] == 0) {
					return json_encode(array('success' => "200",'msg' => "Category Updated."));
				} else {
					return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
				}
			} else {
				return json_encode(array('success' => "0",'msg' => "Category already exist."));
			}
		}
	}

	function manage_user() {
		$ct_email = $this->count_result("users",array("emailId" => $this->input->post('email')));
		$ct_mobile = $this->count_result("users",array("mobile" => $this->input->post('mobile')));
		$ct_username = $this->count_result("users",array("userName" => $this->input->post('username')));
		if(empty($this->input->post('id'))){
			if($this->input->post('pwd') == $this->input->post('cpwd')) {
				if($ct_email == 0 && $ct_mobile == 0 && $ct_username == 0) {
					$data = $this->get_user_post_data();
					$this->db->insert('users',$data);
					$er_ct = $this->db->error(); 
					if($er_ct['code'] == 0) {
						return json_encode(array('success' => "200",'msg' => "User Created.")); 
					} else {
						return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
					}
				} else {
					return json_encode(array('success' => "0",'msg' => "Username/Mobile/Email already exist."));
				}
			} else {
				return json_encode(array('success' => "0",'msg' => "Passwords do not match."));
			}
		} else {
			if($ct_email <= 1 && $ct_mobile <= 1 && $ct_username <= 1) {
				$data = $this->get_user_post_data();
				$this->db->update('users',$data,array('id' => $this->input->post('id')));
				$er_ct = $this->db->error(); 
				if($er_ct['code'] == 0) {
					return json_encode(array('success' => "200",'msg' => "User Updated."));
				} else {
					return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
				}
			} else {
				return json_encode(array('success' => "0",'msg' => "Username/Mobile/Email already exist."));
			}
		}
	}

	function get_user_post_data() {
		$data = array(
			'userName' => $this->input->post('username'),
			'loginName' => $this->input->post('lname'),
			'emailId' => $this->input->post('email'),
			'mobile' => $this->input->post('mobile'),
		);

		if(!empty($this->input->post('pwd'))) {
			$data['password'] = password_hash($this->input->post('pwd'), PASSWORD_DEFAULT);
		}

		return $data;
	}

	function update_user_password() {
		$this->db->update('users',array("password" => password_hash($this->input->post('pwd'), PASSWORD_DEFAULT)),array('id' => $this->input->post('id')));
		$er_ct = $this->db->error(); 
		if($er_ct['code'] == 0) {
			return json_encode(array('success' => "200",'msg' => "User Password Updated."));
		} else {
			return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
		}
	}

	function delete_user() {
		$this->db->update('users',array("delete_stat" => 'Y'),array('id' => $this->input->post('id')));
		$er_ct = $this->db->error(); 
		if($er_ct['code'] == 0) {
			return json_encode(array('success' => "200",'msg' => "User Deleted."));
		} else {
			return json_encode(array('success' => "0",'msg' => "Oops something went wrong."));
		}
	}

}
?>