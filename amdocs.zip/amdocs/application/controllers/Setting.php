<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends CI_Controller {

	public function __construct() {
		parent::__construct();
	    $this->load->model('setting_model','setting');
	    _is_logged_in();
	}

	public function application() {
		$data['type'] = 1;
		$this->layout->view('setting',$data);
	}

	public function fetch_application() {
		echo $this->setting->fetch_application();
	}

	public function motsid_app() {
		$data['type'] = 2;
		$this->layout->view('setting',$data);
	}

	public function category() {
		$data['type'] = 3;
		$this->layout->view('setting',$data);
	}

	public function fetch_motsid_app() {
		echo $this->setting->fetch_motsid_app();
	}

	public function fetch_category() {
		echo $this->setting->fetch_category();
	}

	public function manage_application() {
		$this->form_validation->set_rules('appname', 'Application', 'trim|required|xss_clean');
		if($this->form_validation->run() == TRUE) {
			echo $this->setting->manage_application();
		} else {
			echo json_encode(array('success' => "0",'msg' => validation_errors()));
		}
	}

	public function manage_motsid_app()	{
		$this->form_validation->set_rules('motsid', 'MOTS ID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('appname', 'Application', 'trim|required|xss_clean');
		if($this->form_validation->run() == TRUE) {
			echo $this->setting->manage_motsid_app();
		} else {
			echo json_encode(array('success' => "0",'msg' => validation_errors()));
		}
	}

	public function manage_category()	{
		$this->form_validation->set_rules('category', 'Category', 'trim|required|xss_clean');
		if($this->form_validation->run() == TRUE) {
			echo $this->setting->manage_category();
		} else {
			echo json_encode(array('success' => "0",'msg' => validation_errors()));
		}
	}

}
?>