<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tracker extends CI_Controller {

	public function __construct() {
		parent::__construct();
	    $this->load->model('Tracker_model','tracker');
	    _is_logged_in();
	}

	public function index()	{
		$data['users'] = $this->tracker->fetch_data("users",array("userStatus" => 1,"userType" => 'U'),"loginName,id");
		$data['applications'] = $this->tracker->fetch_data("tr_applications",array("status" => 1),"name,id");
		$this->layout->view('tracker',$data);
	}

	public function compliance()	{
		$data['users'] = $this->tracker->fetch_data("users",array("userStatus" => 1,"userType" => 'U'),"loginName,id");
		$data['motsid'] = $this->tracker->fetch_data("cmp_apps",array("status" => 1),"motsid,id");
		$data['category'] = $this->tracker->fetch_data("cmp_cat",array("status" => 1),"category,id");
		$this->layout->view('compliance',$data);
	}

	public function manage_tracker() {
		$this->form_validation->set_rules('date', 'Date', 'trim|required|xss_clean');
		$this->form_validation->set_rules('application', 'Application', 'trim|required|xss_clean');
		$this->form_validation->set_rules('order_num', 'Order Number', 'trim|required|xss_clean');
		$this->form_validation->set_rules('order_type', 'Order Type', 'trim|xss_clean');
		$this->form_validation->set_rules('Issue_desc', 'Issue Description', 'trim|required|xss_clean');
		$this->form_validation->set_rules('application_t', 'Application', 'trim|required|xss_clean');
		$this->form_validation->set_rules('reported_date', 'Report Date', 'trim|required|xss_clean');
		$this->form_validation->set_rules('status', 'Status', 'trim|required|xss_clean');
        $this->form_validation->set_rules('names', 'Names', 'trim|required|xss_clean');
		$this->form_validation->set_rules('remark', 'Remark', 'trim|required|xss_clean');
		if($this->form_validation->run() == TRUE) {
			echo $this->tracker->manage_tracker();
		} else {
			echo json_encode(array('success' => "0",'msg' => validation_errors()));
		}
	}

	public function manage_compliance()	{
		$this->form_validation->set_rules('date', 'Date', 'trim|required|xss_clean');
		$this->form_validation->set_rules('motsid', 'MOTSID', 'trim|required|xss_clean');
		$this->form_validation->set_rules('task_desc', 'Task Description', 'trim|required|xss_clean');
		$this->form_validation->set_rules('application_t', 'Application', 'trim|required|xss_clean');
		$this->form_validation->set_rules('category', 'Category', 'trim|required|xss_clean');
		$this->form_validation->set_rules('no_of_impact', 'No of Impact', 'trim|required|xss_clean');
		$this->form_validation->set_rules('activity_done', 'Activity done', 'trim|required|xss_clean');
        $this->form_validation->set_rules('names', 'Names', 'trim|required|xss_clean');
		$this->form_validation->set_rules('ticket_no', 'Ticket No', 'trim|required|xss_clean');
		$this->form_validation->set_rules('names', 'Names', 'trim|required|xss_clean');
		if($this->form_validation->run() == TRUE) {
			echo $this->tracker->manage_compliance();
		} else {
			echo json_encode(array('success' => "0",'msg' => validation_errors()));
		}
	}

	public function get_tracker_data() {
		echo $this->tracker->get_tracker_data();
	}

	public function get_compliance_data() {
		echo $this->tracker->get_compliance_data();
	}

	public function delete_tracker() {
		echo $this->tracker->delete_tracker();
	}

	public function delete_compliance() {
		echo $this->tracker->delete_compliance();
	}

	public function fetch_motsid_app() {
		echo $this->tracker->fetch_motsid_app();
	}

}
?>