<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('common_model','common');
		_is_logged_in();
	}

	public function index() {
		$this->layout->view('dashboard',0);
	}
	
	public function event_dashboard($month,$year) {
	    $data['type'] = 0;
		$data['ubc'] = $this->common->get_count("bookings",array("bookingType" => 'B',"bookingStatus" => "Active","status" => 1));
		$data['bkc'] = $this->common->get_count("bookings",array("bookingType" => 'B',"bookingStatus" => "Active","status" => 1,"eventListId" => 5));
		$data['cust'] = $this->common->get_count("customer",array("status" => 1));
		$data['total_amt'] = $this->common->get_total_sum();
		$this->layout->view('dashboard',$data);
	}
	
	public function fetch_calendar() {
		echo $this->common->draw_calendar(date("m"),date("Y"));
	}

	public function fetch_month_calendar()	{
		if(!empty($this->input->post('month')) || !empty($this->input->post('year'))) {
			$op = $this->common->draw_calendar(date("m",strtotime($this->input->post('month'))),$this->input->post('year'));
			$mnth = $this->fetch___month($this->input->post('month'));
	       echo json_encode(array("success" => 200,"cal" => $this->input->post('month')." ".$this->input->post('year'),"month" => $this->input->post('month'),"year" => $this->input->post('year'),"mnth" => $mnth,"op" => $op));
		} else {
			echo json_encode(array("success" => "0"));
		}
	}
	
	public function fetch_month_calendar_()	{
	    if(!empty($this->input->post('month')) || !empty($this->input->post('year'))) {
	       $op = $this->common->draw_calendar($this->input->post('month'),$this->input->post('year'));
	       $mnth = $this->fetch__month($this->input->post('month'));
	       echo json_encode(array("success" => 200,"cal" => $mnth." ".$this->input->post('year'),"month" => $this->input->post('month'),"year" => $this->input->post('year'),"mnth" => $mnth,"op" => $op));
		} else {
		  echo json_encode(array("success" => "0"));

		}
	}

	function fetch_calendar_date_left() {
		$month = $this->input->post('month');
		$year = $this->input->post('year');
		if($month == 1) {
			$month = 12;
			$year--;
		} else {
			$month--;
		}
		$op = $this->common->draw_calendar($month,$year);
		$mnth = $this->fetch__month($month);
		echo json_encode(array("cal" => $mnth." ".$year,"month" => $month,"year" => $year,"mnth" => $mnth,"op" => $op));
	}

	function fetch__month($month) {
		$mth = array(1 => "January",2 => "February",3 => "March",4 => "April",5 => "May",6 => "June",7 => "July",8 => "August",9 => "September",10 => "October",11 => "November",12 => "December");
		foreach($mth as $key => $val) {
			if($key == $month) {
				return $val;
			}
		}
	} 
	
	function fetch___month($month) {
		$mth = array(1 => "January",2 => "February",3 => "March",4 => "April",5 => "May",6 => "June",7 => "July",8 => "August",9 => "September",10 => "October",11 => "November",12 => "December");
		foreach($mth as $key => $val) {
			if($val == $month) {
				return $key;
			}
		}
	}  
	
	function fetch_calendar_date_right() {
		$month = $this->input->post('month');
		$year = $this->input->post('year');
		if($month == 12) {
			$month = 1;
			$year++;
		} else {
			$month++;
		}
		$op = $this->common->draw_calendar($month,$year);
		$mnth = $this->fetch__month($month);
		echo json_encode(array("cal" => $mnth." ".$year,"month" => $month,"year" => $year,"mnth" => $mnth,"op" => $op));
	}

	public function modify_status() {
		$id=$this->input->post("id");
		$status=$this->input->post("status");
		$result=$this->common->change_status($id,$status);
		echo $result;
	}
	
	public function report() {
		$data['type'] = 1;
		$this->layout->view('dashboard',$data);
	}

	public function download_upcoming_bking() {
		$this->common->download_upcoming_bking();
	}

	public function download_completed_events() {
		$this->common->download_completed_events();
	}

	public function download_cancelled_events() {
		$this->common->download_cancelled_events();
	}

	public function map_ids() {
		$this->common->map_ids();
	}
	
	public function mm_sms_send() {
	    $this->form_validation->set_rules('mobile', 'Mobile', 'trim|required|min_length[10]|xss_clean');
	    $this->form_validation->set_rules('sms_msg', 'SMS Template', 'trim|required|xss_clean');
        if($this->form_validation->run() == TRUE) {
		    echo $this->common->send_bk_sms();
		} else {
			echo validation_errors();
		}
	}
	
	public function all_cust_sms_send() {
	    $this->form_validation->set_rules('sms_msg', 'SMS Template', 'trim|required|xss_clean');
        if($this->form_validation->run() == TRUE) {
	        echo $this->common->all_cust_sms_send();
        } else {
			echo validation_errors();
		}
	}
	
	public function test_message() {
       echo $this->common->send_sms("8123506819","Greetings: Thank You for Booking Mali Manch, Wish Your Event Be Joyful & Memorable. www.malimanch.com");
	}

}

?>