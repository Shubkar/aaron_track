<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

	public function __construct() {
		parent::__construct();
	    $this->load->model('auth_model','auth');
	}

	public function index() {
		$this->load->view('auth');
	}

	public function validate_user() {
		$this->form_validation->set_rules('mali_username', 'User Name', 'trim|required|xss_clean');
		$this->form_validation->set_rules('mali_password', 'Password', 'trim|required|min_length[6]|max_length[12]|xss_clean');
		if($this->form_validation->run() == TRUE) {
			$result = $this->auth->validate_user();
			if($result == 200) {
				$this->session->set_flashdata('success', "Successfully Logged in");
        		redirect(base_url('dashboard'),'refresh');
			} else {
				$this->session->set_flashdata('error', $result);
			}
		} else {
			$this->session->set_flashdata('error', validation_errors());
		}
		redirect(base_url(),'refresh');
	}

	function change_password() {
		echo $this->auth->change_password();
	}

	public function logout() {
		$this->session->sess_destroy();
		redirect(base_url(),'refresh');
	}
}
