<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct() {
		parent::__construct();
	    $this->load->model('setting_model','setting');
	    _is_logged_in();
	}

	public function customers()	{
		$data['type'] = 4;
		$this->layout->view('setting',$data);
	}

	public function fetch_customers() {
		echo $this->setting->fetch_customers();
	}

	public function users()	{
		$data['type'] = 5;
		$this->layout->view('setting',$data);
	}

	public function fetch_users() {
		echo $this->setting->fetch_users();
	}

	public function manage_user()	{
		if(empty($this->input->post('id'))){
			$this->form_validation->set_rules('lname', 'Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
			$this->form_validation->set_rules('mobile', 'Mobile', 'trim|required|min_length[10]|max_length[10]|xss_clean');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean|valid_email');
			$this->form_validation->set_rules('pwd', 'Password', 'trim|required|min_length[6]|max_length[12]|xss_clean');
			$this->form_validation->set_rules('cpwd', 'Confirm Password', 'trim|min_length[6]|max_length[12]|required|xss_clean');
		} else {
			$this->form_validation->set_rules('lname', 'Name', 'trim|required|xss_clean');
			$this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
			$this->form_validation->set_rules('mobile', 'Mobile', 'trim|required|min_length[10]|max_length[10]|xss_clean');
			$this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean|valid_email');
		}
		if($this->form_validation->run() == TRUE) {
			echo $this->setting->manage_user();
		} else {
			echo json_encode(array('success' => "0",'msg' => validation_errors()));
		}
	}

	public function update_user_password()	{
		$this->form_validation->set_rules('pwd', 'Password', 'trim|required|min_length[6]|max_length[12]|xss_clean');
		if($this->form_validation->run() == TRUE) {
			echo $this->setting->update_user_password();
		} else {
			echo json_encode(array('success' => "0",'msg' => validation_errors()));
		}
	}

	public function delete_user() {
		echo $this->setting->delete_user();
	}
}
?>