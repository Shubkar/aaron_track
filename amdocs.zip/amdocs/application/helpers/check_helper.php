<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 
    function _is_logged_in() {
        if(!isset($_SESSION['aD_min_id'])  && !isset($_SESSION['aD_min_LoGGedIn'])) {
            redirect(base_url());        
        } 
    }
?>