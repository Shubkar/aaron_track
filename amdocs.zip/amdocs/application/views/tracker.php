<section class="p-2">
  <div class="container-fluid">
    <div class="mb-5">
      <h4 class="flaot-start">Tracker</h4>
      <button class="btn btn-primary me-md-2 float-end" type="button" data-bs-toggle="modal" data-bs-target="#addrecordsmodal" style="margin-top: -2.25rem !important;">Add Record</button>
      <hr>
    </div>

    <div class="table-responsive">
      <table class="table table-striped tracker_record_dt">
        <thead class="thead-primary">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Date</th>
            <th scope="col">Application</th>
            <th scope="col">Order #</th>
            <th scope="col">Order desc</th>
            <th scope="col">Issue Desription</th>
            <th scope="col">Application TA</th>
            <th scope="col">Reported Date</th>
            <th scope="col">Status</th>
            <th scope="col">Names</th>
            <th scope="col">Remark</th>
            <th scope="col">Delete</th>
          </tr>
        </thead>
        <tbody>
          
        </tbody>
      </table>
    </div>
  </div>
</section>
<!-- Enter User Modal -->
<div class="modal fade" id="addrecordsmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tracker Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array('class' => 'manage_tracker'))?>
        <div class="modal-body">
          <div class="row row-cols-3">
            <div class="col">
              <label>Current Date</label>
              <div class="input-group mb-3">
                <span class="input-group-text">Current Date &nbsp;&nbsp;</span>
                <input type="date" id="today" class="form-control" name="date" placeholder="Date" value="<?=date('Y-m-d')?>">
              </div>
            </div>
            <input type="hidden" name="id">
            <div class="col">
              <label>Application</label>
              <div class="input-group mb-3">
                  <select class="form-select" id="" name="application">
                    <option selected disabled hidden>Select Application</option>
                    <?php foreach($applications->result() as $row) : ?>
                      <option value="<?=$row->id?>"><?=$row->name?></option>
                    <?php endforeach; ?>
                  </select>
              </div>
            </div>
            <div class="col">
              <label>Order No</label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="order_num"  placeholder="Order #" aria-label="date" >
              </div>
            </div>
            <div class="col">
              <label>Order Type</label>
              <div class="input-group mb-3">
                  <select class="form-select" id="" name="order_type">
                    <option selected disabled hidden>Order Type</option>
                    <option value="Change">Change</option>
                    <option value="Disconnected">Disconnected</option>
                    <option value="New">New</option>
                    <option value="Record">Record</option>
                  </select>
              </div>
            </div>
            <div class="col">
              <label>Issue Description</label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="Issue_desc" placeholder="Issue Description" aria-label="date" >
              </div>
            </div>
            <div class="col">
                <label>Application T.A</label>
                <div class="input-group mb-3">
                  <select class="form-select" id="" name="application_t">
                    <option selected hidden disabled>Application T.A</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>                
                  </select>
                </div>
            </div>
            <div class="col">
              <label>Reported Date</label>
              <div class="input-group mb-3">
                <span class="input-group-text">Reported Date</span>
                <input type="date" class="form-control" name="reported_date"  placeholder="Reporting date" aria-label="date" >
              </div>
            </div>
            <div class="col">
              <label>Status</label>
               <div class="input-group mb-3">
                  <select class="form-select" id="" name="status" >
                    <option selected hidden disabled>Status</option>
                    <option value="Open">Open</option> 
                    <option value="Closed">Closed</option>
                    <option value="In Progress">In Progress</option>                                  
                  </select>
                </div>
            </div>
            <div class="col">
              <label>User</label>
              <div class="input-group mb-3">
                  <select class="form-select" id="" name="names" >
                    <option selected disabled hidden>Select Name</option>
                    <?php foreach($users->result() as $row) : ?>
                      <option value="<?=$row->id?>"><?=$row->loginName?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
            </div>
            <div class="col">
              <label>Remarks</label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="remark" placeholder="Remarks" aria-label="date" >
              </div>
            </div>
          </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>


<!-- Enter Event Modal -->
<div class="modal fade" id="delete_record_modal" tabindex="-1" aria-labelledby="sms_modal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="sms_modal">Delete Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array("class" => "delete_tracker_record"))?>
      <div class="modal-body">
          <input type="hidden" name="id">
          <h2 class="text-center text-danger">Are you sure you want to delete ?</h2>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>