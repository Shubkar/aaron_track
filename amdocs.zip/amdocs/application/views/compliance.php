<section class="p-2">
  <div class="container-fluid">
    <div class="mb-5">
      <h4 class="flaot-start">Compliance</h4>
      <button class="btn btn-primary me-md-2 float-end" type="button" data-bs-toggle="modal" data-bs-target="#addrecordscmpmodal" style="margin-top: -2.25rem !important;">Add Record</button>
      <hr>
    </div>

    <div class="table-responsive">
      <table class="table table-striped compliance_record_dt">
        <thead class="thead-primary">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Date</th>
            <th scope="col">MOTS ID</th>
            <th scope="col">Application</th>
            <th scope="col">Application TA</th>
            <th scope="col">Category</th>
            <th scope="col">Task Desription</th>
            <th scope="col">Number of Impact</th>
            <th scope="col">Activity Done</th>
            <th scope="col">Ticket Number</th>
            <th scope="col">Application Owner</th>
            <th scope="col">Delete</th>
          </tr>
        </thead>
        <tbody>
          
        </tbody>
      </table>
    </div>
  </div>
</section>
<!-- Enter User Modal -->
<div class="modal fade" id="addrecordscmpmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tracker Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array('class' => 'manage_compliance'))?>
        <div class="modal-body">
          <div class="row row-cols-3">
            <div class="col">
              <label>Current Date</label>
              <div class="input-group mb-3">
                <span class="input-group-text">Current Date &nbsp;&nbsp;</span>
                <input type="date" id="today" class="form-control" name="date" placeholder="Date" value="<?=date('Y-m-d')?>">
              </div>
            </div>
            <input type="hidden" name="id">
            <div class="col">
              <label>MOTS ID</label>
              <div class="input-group mb-3">
                  <select class="form-select" id="motsid" name="motsid">
                    <option selected disabled hidden>Select MOTS ID</option>
                    <?php foreach($motsid->result() as $row) : ?>
                      <option value="<?=$row->id?>"><?=$row->motsid?></option>
                    <?php endforeach; ?>
                  </select>
              </div>
            </div>
            <div class="col">
              <label>Application</label>
              <div class="input-group mb-3">
                  <input type="text" name="application" id="cmpapp" class="form-control" readonly>
              </div>
            </div>
            <div class="col">
                <label>Application T.A</label>
                <div class="input-group mb-3">
                  <select class="form-select" id="" name="application_t">
                    <option selected hidden disabled>Select Application T.A</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>                
                  </select>
                </div>
            </div>
            <div class="col">
                <label>Category</label>
                <div class="input-group mb-3">
                  <select class="form-select" id="" name="category">
                    <option selected hidden disabled>Select Category</option>
                    <?php foreach($category->result() as $row) : ?>
                      <option value="<?=$row->id?>"><?=$row->category?></option>
                    <?php endforeach; ?>               
                  </select>
                </div>
            </div>
            <div class="col">
              <label>Task Description</label>
              <div class="input-group mb-3">
                <textarea class="form-control" name="task_desc" placeholder="Task Description"></textarea>
              </div>
            </div>
            <div class="col">
              <label>Number of Impact</label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="no_of_impact"  placeholder="Number of Impact">
              </div>
            </div>
            <div class="col">
              <label>Activity Done</label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="activity_done"  placeholder="Activity Done">
              </div>
            </div>
            <div class="col">
              <label>Ticket No</label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="ticket_no"  placeholder="Ticket No">
              </div>
            </div>
            <div class="col">
              <label>Application Owner</label>
              <div class="input-group mb-3">
                  <select class="form-select" id="" name="names" >
                    <option selected disabled hidden>Select Name</option>
                    <?php foreach($users->result() as $row) : ?>
                      <option value="<?=$row->id?>"><?=$row->loginName?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
            </div>
          </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>


<!-- Enter Event Modal -->
<div class="modal fade" id="delete_comprecord_modal" tabindex="-1" aria-labelledby="sms_modal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="sms_modal">Delete Record</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array("class" => "delete_compliance_record"))?>
      <div class="modal-body">
          <input type="hidden" name="id">
          <h2 class="text-center text-danger">Are you sure you want to delete ?</h2>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>