<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Login </title>
        <link href="<?=base_url('assets/css/styles.css')?>" rel="stylesheet" />
        <script src="<?=base_url('assets/js/all.min.js')?>" crossorigin="anonymous"></script>
        <style>
            .eye{
                position: absolute;
                top: 245px;
                right: 25px;
                cursor: pointer;
            }
        </style>    </head>
    <body style="background-color: #b0b2b3;">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <?php if(!empty($this->session->flashdata('error'))) : ?>
                                    <div class="alert alert-danger d-flex align-items-center mt-5" role="alert">
                                      <div>
                                        <?=$this->session->flashdata('error')?>
                                      </div>
                                    </div>
                                <?php endif; ?>
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header">
                                        <h2 class="text-center">Amdocs Help Desk Tracker</h2>
                                    </div>
                                    <div class="card-body">
                                        <?=form_open("validate_user",array("name" => "mali_bms"))?>
                                            <div class="form-group mb-3">
                                                <label for="mali_username">User Name</label>
                                                <input class="form-control" name="mali_username" type="text" placeholder="Enter Username" />
                                            </div>
                                            <div class="form-group mb-3">
                                                <label for="mali_password">Password</label>
                                                <input class="form-control" name="mali_password" id="mali_password" type="password" placeholder="Password" />
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <button class="btn btn-primary" type="submit">Login</button>
                                            </div>
                                        <?=form_close()?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="<?=base_url('assets/js/jquery-3.6.0.min.js')?>"></script>
        <script src="<?=base_url('assets/js/bootstrap.bundle.min.js')?>" crossorigin="anonymous"></script>
        <script src="<?=base_url('assets/js/scripts.js')?>"></script>
        <script src="<?=base_url('assets/js/jquery.validate.js')?>"></script>
        <script>
            $(function() {
              $("form[name='mali_bms']").validate({
                rules: {
                  mali_username: "required",
                  mali_password: {
                    required: true,
                    rangelength: [6, 12]
                  }
                },
                messages: {
                  mali_username: "Username is required to login",
                  mali_password: {
                    required: "Password is required to login",
                    rangelength: "Your password must be at least 6 characters long and less than 12 characters long"
                  }
                },
                submitHandler: function(form) {
                  form.submit();
                }
              });
            });
         </script>
    </body>
</html>
