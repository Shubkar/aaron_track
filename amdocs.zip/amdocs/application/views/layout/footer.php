</main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Help Desk Tracker</div>
                            <div class="text-muted"></div>
                        </div>
                    </div>
                </footer>
            </div>

        <!-- Enter Event Modal -->
<div class="modal fade" id="password_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array("class" => "change_password_"))?>
      <div class="modal-body">
        <div class="form-group">
          <label>Password</label>  
          <input type="password" name="password" class="form-control" placeholder="Enter Password" autocomplete="off">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      <?=form_close()?>
  </div>
</div>
</div>

 <div class="loader">
  <div class="load_center">
    <img src="assets/img/loader.gif" class="img-fluid">
  </div>
</div> 

<script src="<?=base_url('assets/js/jquery-3.6.0.min.js')?>"></script>
<script src="<?=base_url('assets/js/bootstrap.bundle.min.js')?>"></script>
<script src="<?=base_url('assets/js/scripts.js')?>"></script>
<script src="<?=base_url('assets/js/toastr-master/build/toastr.min.js')?>"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/v/bs5/jq-3.6.0/jszip-2.5.0/dt-1.11.2/af-2.3.7/b-2.0.0/b-colvis-2.0.0/b-html5-2.0.0/b-print-2.0.0/cr-1.5.4/date-1.1.1/fc-3.3.3/fh-3.1.9/kt-2.6.4/r-2.2.9/rg-1.1.3/rr-1.2.8/sc-2.0.5/sb-1.2.1/sp-1.4.0/sl-1.3.3/datatables.min.js"></script>
<script src="<?=base_url('assets/js/jquery-ui.min.js')?>"></script>

<script>
  <?php if(!empty($this->session->flashdata('error'))) : ?>
  toastr.error("<?=$this->session->flashdata('error')?>");
  <?php endif; ?>
  
  <?php if(!empty($this->session->flashdata('success'))) : ?>
  toastr.success("<?=$this->session->flashdata('success')?>");
  <?php endif; ?>


  function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
  }

  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }  toastr.options = {
               "closeButton": true,
               "onclick": null,
               "showDuration": "300000",
               "hideDuration": "1000",
               "timeOut": "8000",
               "extendedTimeOut": "1000",
               "showEasing": "swing",
               "hideEasing": "linear",
               "showMethod": "fadeIn",
               "hideMethod": "fadeOut"
           };
  var url = "<?=base_url()?>";

  $('.manage_tracker').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"tracker/manage_tracker",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('.manage_tracker').trigger("reset");
              $('#addrecordsmodal').modal('hide');
              $('.tracker_record_dt').DataTable().ajax.reload();
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }
      });
  });

    $('.manage_compliance').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"tracker/manage_compliance",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('.manage_compliance').trigger("reset");
              $('#addrecordscmpmodal').modal('hide');
              $('.compliance_record_dt').DataTable().ajax.reload();
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }
      });
  });

  $('.delete_tracker_record').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"tracker/delete_tracker",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('#delete_record_modal').modal('hide');
              $('.tracker_record_dt').DataTable().ajax.reload();
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }
      });
  });

  $('.delete_compliance_record').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"tracker/delete_compliance",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('#delete_comprecord_modal').modal('hide');
              $('.compliance_record_dt').DataTable().ajax.reload();
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }
      });
  });

  $(document).ready(function() {
      $('.tracker_record_dt').DataTable( {
        "ajax": {
            "url": url+"tracker/get_tracker_data",
            "type": "POST",
            "dataSrc": ""
        },
        "columns": [
            { "data": "sl" },
            { "data": "date" },
            { "data": "application" },
            { "data": "order_no" },
            { "data": "order_desc" },
            { "data": "issue_desc" },
            { "data": "app_ta" },
            { "data": "reported_date" },
            { "data": "status" },
            { "data": "name" },
            { "data": "remark" },
            { "data": "Action" }
        ]
    });
  });

    $(document).ready(function() {
      $('.compliance_record_dt').DataTable( {
        "ajax": {
            "url": url+"tracker/get_compliance_data",
            "type": "POST",
            "dataSrc": ""
        },
        "columns": [
            { "data": "sl" },
            { "data": "date" },
            { "data": "motsid" },
            { "data": "application" },
            { "data": "application_ta" },
            { "data": "category" },
            { "data": "task_desc" },
            { "data": "no_of_impact" },
            { "data": "activity_done" },
            { "data": "ticket_no" },
            { "data": "user" },
            { "data": "Action" }
        ]
    });
  });

  $('#addrecordsmodal').on('show.bs.modal', function(e) {
     var id = $(e.relatedTarget).data('id');
     var date = $(e.relatedTarget).data('date');
     var application = $(e.relatedTarget).data('application');
     var order_no = $(e.relatedTarget).data('order_no');
     var order_desc = $(e.relatedTarget).data('order_desc');
     var issue_desc = $(e.relatedTarget).data('issue_desc');
     var app_ta = $(e.relatedTarget).data('app_ta');
     var reported_date = $(e.relatedTarget).data('reported_date');
     var status = $(e.relatedTarget).data('status');
     var name = $(e.relatedTarget).data('name');
     var remark = $(e.relatedTarget).data('remark');
     $(e.currentTarget).find('input[name="id"]').val(id);
     $(e.currentTarget).find('input[name="date"]').val(date);
     $(e.currentTarget).find('select[name="application"]').val(application);
     $(e.currentTarget).find('input[name="order_num"]').val(order_no);
     $(e.currentTarget).find('select[name="order_type"]').val(order_desc);
     $(e.currentTarget).find('input[name="Issue_desc"]').val(issue_desc);
     $(e.currentTarget).find('select[name="application_t"]').val(app_ta);
     $(e.currentTarget).find('input[name="reported_date"]').val(reported_date);
     $(e.currentTarget).find('select[name="status"]').val(status);
     $(e.currentTarget).find('input[name="names"]').val(name);
     $(e.currentTarget).find('input[name="remark"]').val(remark);
  });

  $('#addrecordscmpmodal').on('show.bs.modal', function(e) {
     var id = $(e.relatedTarget).data('id');
     var date = $(e.relatedTarget).data('date');
     var motsid = $(e.relatedTarget).data('motsid');
     var application = $(e.relatedTarget).data('application');
     var category = $(e.relatedTarget).data('category');
     var no_of_impacty = $(e.relatedTarget).data('no_of_impacty');
     var task_desc = $(e.relatedTarget).data('task_desc');
     var app_ta = $(e.relatedTarget).data('app_ta');
     var activity_done = $(e.relatedTarget).data('activity_done');
     var ticket_no = $(e.relatedTarget).data('ticket_no');
     var name = $(e.relatedTarget).data('name');
     $(e.currentTarget).find('input[name="id"]').val(id);
     $(e.currentTarget).find('input[name="date"]').val(date);
     $(e.currentTarget).find('select[name="motsid"]').val(motsid);
     $(e.currentTarget).find('input[name="application"]').val(application);
     $(e.currentTarget).find('input[name="category"]').val(category);
     $(e.currentTarget).find('input[name="no_of_impact"]').val(no_of_impacty);
     $(e.currentTarget).find('textarea[name="task_desc"]').val(task_desc);
     $(e.currentTarget).find('select[name="application_t"]').val(app_ta);
     $(e.currentTarget).find('input[name="activity_done"]').val(activity_done);
     $(e.currentTarget).find('input[name="ticket_no"]').val(ticket_no);
     $(e.currentTarget).find('select[name="names"]').val(name);
  });

  $('#delete_record_modal').on('show.bs.modal', function(e) {
     var id = $(e.relatedTarget).data('id');
     $(e.currentTarget).find('input[name="id"]').val(id);
  });

  $('#delete_comprecord_modal').on('show.bs.modal', function(e) {
     var id = $(e.relatedTarget).data('id');
     $(e.currentTarget).find('input[name="id"]').val(id);
  });

  $("#motsid").change(function(){
    var id = $("#motsid").val();
    $.post(url+"tracker/fetch_motsid_app",
      {
        id: id
      },
      function(data){
         var obj = JSON.parse(data);
         if(obj.success == 200) {
          $("#cmpapp").val(obj.val);
         } else {
          toastr.error(obj.msg);
         }
      });
  });

</script>
 
<script>
  var url = "<?=base_url()?>";
  $(document).on('change', '.chkbx', function() {
      var id = $(this).attr("id"); 
      var status = $(this).attr("value");
      $.post(url+"modify_status",
      {
        id: id,
        status: status
      },
      function(data){
         var obj = JSON.parse(data);
         if(obj.success == true) {
           $('.chkbx').val(obj.status);
           toastr.success('Status Changed');
         } else {
          toastr.error('Unable to change the status');
         }
      });
  });

  $(document).ready(function() {
      $('.application_datatable').DataTable( {
        "ajax": {
            "url": url+"setting/fetch_application",
            "type": "POST",
            "dataSrc": ""
        },
        "columns": [
            { "data": "sl" },
            { "data": "application" },
            { "data": "status" },
            { "data": "buttons" }
        ]
    });
  });

  $(document).ready(function() {
      $('.category_datatable').DataTable( {
        "ajax": {
            "url": url+"setting/fetch_category",
            "type": "POST",
            "dataSrc": ""
        },
        "columns": [
            { "data": "sl" },
            { "data": "name" },
            { "data": "status" },
            { "data": "buttons" }
        ]
    });
  });

  $('.manage_app').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"setting/manage_application",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('#addApplication').modal('hide');
              $('.manage_app').trigger("reset");
              $('.application_datatable').DataTable().ajax.reload();
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }
      });
  });

  $('#addApplication').on('show.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    var name = $(e.relatedTarget).data('name');
     $(e.currentTarget).find('input[name="id"]').val(id);
     $(e.currentTarget).find('input[name="appname"]').val(name);
  });

    $('.manage_category').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"setting/manage_category",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('#addcategory').modal('hide');
              $('.manage_category').trigger("reset");
              $('.category_datatable').DataTable().ajax.reload();
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }
      });
  });

  $('#addcategory').on('show.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    var name = $(e.relatedTarget).data('name');
     $(e.currentTarget).find('input[name="id"]').val(id);
     $(e.currentTarget).find('input[name="category"]').val(name);
  });

  $('.change_password_').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"auth/change_password",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('#password_modal').modal('hide');
              $('#change_password_').trigger("reset");
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }

      });
  });

    $(document).ready(function() {
      $('.motsid_dt').DataTable( {
        "ajax": {
            "url": url+"setting/fetch_motsid_app",
            "type": "POST",
            "dataSrc": ""
        },
        "columns": [
            { "data": "sl" },
            { "data": "motsid" },
            { "data": "appname" },
            { "data": "status" },
            { "data": "buttons" }
        ]
    });
  });

  $('.manage_motsid').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"setting/manage_motsid_app",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('#addmotisd').modal('hide');
              $('.manage_motsid').trigger("reset");
              $('.motsid_dt').DataTable().ajax.reload();
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }

      });
  });

  $('#addmotisd').on('show.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    var appname = $(e.relatedTarget).data('appname');
    var motsid = $(e.relatedTarget).data('motsid');
     $(e.currentTarget).find('input[name="id"]').val(id);
     $(e.currentTarget).find('input[name="appname"]').val(appname);
     $(e.currentTarget).find('input[name="motsid"]').val(motsid);
  });


  $(document).ready(function() {
      $('.users_dt').DataTable( {
        "ajax": {
            "url": url+"users/fetch_users",
            "type": "POST",
            "dataSrc": ""
        },
        "columns": [
            { "data": "sl" },
            { "data": "loginName" },
            { "data": "username" },
            { "data": "mobile" },
            { "data": "email" },
            { "data": "register_on" },
            { "data": "status" },
            { "data": "buttons" }
        ]
    });
  });

  $('#editusersModal').on('show.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    var loginName = $(e.relatedTarget).data('ln');
    var username = $(e.relatedTarget).data('username');
    var mobile = $(e.relatedTarget).data('mobile');
    var email = $(e.relatedTarget).data('email');
    var user_type = $(e.relatedTarget).data('usertype');
     $(e.currentTarget).find('input[name="id"]').val(id);
     $(e.currentTarget).find('input[name="lname"]').val(loginName);
     $(e.currentTarget).find('input[name="username"]').val(username);
     $(e.currentTarget).find('input[name="mobile"]').val(mobile);
     $(e.currentTarget).find('input[name="email"]').val(email);
     $(e.currentTarget).find('select[name="user_type"]').val(user_type);
  });

  $('#change_user_password').on('show.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    $(e.currentTarget).find('input[name="id"]').val(id);
  });
  
  $('#delete_cid_modal').on('show.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    var name = $(e.relatedTarget).data('name');
    $(e.currentTarget).find('input[name="id"]').val(id);
    $('.custormar').text(name);
  });
  
  

  $('.manage_user').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"users/manage_user",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('#addusersmodal').modal('hide');
              $('#editusersModal').modal('hide');
              $('.manage_user').trigger("reset");
              $('.users_dt').DataTable().ajax.reload();
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }
      });
  });

  $('.update_user_password').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"users/update_user_password",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('#change_user_password').modal('hide');
              $('.update_user_password').trigger("reset");
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }
      });
  });

  $('#delete_user_modal').on('show.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    var name = $(e.relatedTarget).data('name');
    $(e.currentTarget).find('input[name="id"]').val(id);
    $('.custordlemar').text(name);
  });

  $('.delete_user').submit(function(e) {
      e.preventDefault();
      var data = new FormData(this); 
      $.ajax({
          url: url+"users/delete_user",
          data: data,
          cache: false,
          contentType: false,
          processData: false,
          type: 'POST',
          success: function(data) {
            const obj = JSON.parse(data);
             if(obj.success == 200) {
              $('.users_dt').DataTable().ajax.reload();
              $('#delete_user_modal').modal('hide');
              $('.delete_user').trigger("reset");
              toastr.success(obj.msg);
             } else toastr.error(obj.msg);
          }
      });
  });

  $(window).on('load', function () {
    const myTimeout = setTimeout(closeloader, 5000);
  });

  function closeloader() {
    $('.loader').hide();
  }
</script>

    </body>
</html>


 
