<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');  ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Help Desk Tracker </title>
       
        <link href="<?=base_url('assets/css/styles.css')?>" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/jq-3.6.0/jszip-2.5.0/dt-1.11.2/af-2.3.7/b-2.0.0/b-colvis-2.0.0/b-html5-2.0.0/b-print-2.0.0/cr-1.5.4/date-1.1.1/fc-3.3.3/fh-3.1.9/kt-2.6.4/r-2.2.9/rg-1.1.3/rr-1.2.8/sc-2.0.5/sb-1.2.1/sp-1.4.0/sl-1.3.3/datatables.min.css"/>
        <link rel="stylesheet"  href="<?=base_url('assets/js/toastr-master/build/toastr.css')?>">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="<?=base_url('assets/js/jquery-ui.min.css')?>" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css" />
        <link rel="stylesheet" href="<?=base_url('assets/js/select2/dist/css/select2.css')?>" />
        <style>
            .fc-content {
                font-size: 1em;
                font-weight: 700;
                color: #fff;
                padding: 1em;
                white-space: normal !important;
            }
            
            .fc-unthemed td.fc-today {
                background: #04a0da !important;
                color: #fff;
            }

            .sidenav {
              height: 100%;
              width: 0;
              position: fixed;
              z-index: 15656;
              top: 0;
              left: 0;
              background-color: #111;
              overflow-x: hidden;
              transition: 0.5s;
              padding-top: 60px;
            }

            .sidenav a {
              padding: 8px 8px 8px 32px;
              text-decoration: none;
              font-size: 1em;
              color: #818181;
              display: block;
              transition: 0.3s;
            }

            .sidenav a:hover {
              color: #f1f1f1;
            }

            .sidenav .closebtn {
              position: absolute;
              top: 0;
              right: 25px;
              font-size: 36px;
              margin-left: 50px;
            }

            @media screen and (max-height: 450px) {
              .sidenav {padding-top: 15px;}
              .sidenav a {font-size: 18px;}
            }
            
                        /* calendar */
            table.calendar    { border-left:1px solid #999;    width: 100%; }
            tr.calendar-row {  }
            td.calendar-day { min-height:95px; font-size:11px; position:relative; } * html div.calendar-day { height:95px; }
            /*td.calendar-day:hover { background:#eceff5;z-index:0; }*/
            td.calendar-day-np  { background:#eee;min-height:95px; font-size:11px; position:relative; } * html div.calendar-day-np { height:95px; }
            td.calendar-day-head { background:#ccc; font-weight:bold; text-align:center; width:95px; padding:3px;padding-left: 48px;padding-right: 48px; border-bottom:1px solid #999; border-top:1px solid #999; border-right:1px solid #999; }
            div.day-number    { 
              background:#999; 
              padding:5px; 
              color:#fff; 
              font-weight:bold; 
              width:20px;
              /*margin-left: auto;margin-right: auto; margin-bottom:2em;*/
              position: absolute;
              top: 2%;
              left: 48%;
            }
            /* shared */
            td.calendar-day, td.calendar-day-np { width:182px;height: 95px; padding:5px; border-bottom:1px solid #999; border-right:1px solid #999; }
            div.day-number-active {
                background: #181515;
                padding: 5px;
                color: #fff;
                font-weight: bold;
                width: 20px;
                /*margin-left: auto;margin-right: auto; margin-bottom:2em;*/
              position: absolute;
              top: 2%;
              left: 48%;
            }
            div.day-number-holiday {
              background: #2187c2;
              padding: 5px;
              color: #fff;
              font-weight: bold;
              width: 20px;
              position: absolute;
              top: 2%;
              left: 48%;
            }
            div.day-number-holiday-active {
              background: #3a6822;
              padding: 5px;
              color: #fff;
              font-weight: bold;
              width: 20px;
              position: absolute;
              top: 2%;
              left: 48%;
            }
            .loader{
              position: fixed;
              background-color: #fff;
              height: 100vh;
              width: 100%;
              z-index: 555555;
            }

            .load_center{
              position: relative;
              top: 50%;
              -webkit-transform: translateY(-50%);
              -ms-transform: translateY(-50%);
              transform: translateY(-50%);
            }
        </style>
    </head>
    <body class="sb-nav-fixed">
        <div id="mySidenav" class="sidenav">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
          <a class="nav-link" href="<?=base_url('dashboard')?>">
            <i class="fas fa-calendar-week"></i>
            Dashboard
           </a>
            <?php if($this->session->userdata('aD_User_type') == 'A') : ?>
          <a class="nav-link" href="<?=base_url('users')?>">
            <i class="far fa-chart-bar"></i>
            Users
          </a>
          <a class="nav-link" href="<?=base_url('setting/application')?>">
            <i class="far fa-chart-bar"></i>
            Settings
          </a>
            <a class="nav-link" href="<?=base_url('report')?>">
            <i class="far fa-chart-bar"></i>
            Report
          </a>
        <?php endif; ?>
        </div>
        <nav class="navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="<?=base_url('dashboard')?>">Help Desk Tracker</a>
            <!-- Sidebar Toggle-->
            <span class="" style="font-size:30px;cursor:pointer;color: #fff;" onclick="openNav()">&#9776;</span>
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
            <div class="d-none d-sm-block d-md-block mx-auto">
              <ul class="navbar-nav  mb-2 mb-lg-0">
                <li class="nav-item">
                  <a class="nav-link" href="<?=base_url('dashboard')?>">
                    <i class="fas fa-calendar-week"></i>
                    Dashboard
                  </a>
                </li>
                <?php if($this->session->userdata('aD_User_type') == 'A') : ?>
                <li class="nav-item">
                  <a class="nav-link" href="<?=base_url('users')?>">
                    <i class="fas fa-calendar-week"></i>
                    Users
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?=base_url('setting/application')?>">
                    <i class="fas fa-calendar-week"></i>
                    Settings
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="<?=base_url('report')?>">
                    <i class="far fa-chart-bar"></i>
                    Report
                  </a>
                </li>
              <?php endif; ?>
              </ul>
            </div>
            </div>

            <!-- Navbar-->
            <ul class="navbar-nav  ms-auto ms-md-0 me-3 me-lg-4">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                        <!--<li><a class="dropdown-item" href="#!" data-bs-toggle="modal" data-bs-target="#pfrofile_modal" >Profile</a></li>-->
                        <li><a class="dropdown-item" href="#!" data-bs-toggle="modal" data-bs-target="#password_modal" >Change Password</a></li>
                        <li><hr class="dropdown-divider" /></li>
                        <li><a class="dropdown-item" href="<?=base_url('logout')?>">Logout</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <div id="">
            <main>