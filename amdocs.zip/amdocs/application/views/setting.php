<?php if($type == 1) : ?>
<section class="p-2">
  <div class="container-fluid">
  	<div class="mb-5">
      <ul class="nav nav-tabs">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?=base_url('setting/application')?>">Application</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('setting/motsid_app')?>">MOTSID Application</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('setting/category')?>">Compliance Category</a>
          </li>
      </ul>
      <button class="btn btn-primary float-end btn_margin btn-sm" data-bs-toggle="modal" data-bs-target="#addApplication" style="margin-top: -2.25rem !important;">Add Application</button>
    </div>
    <div class="table-responsive">
      <table class="table table-striped dd application_datatable">
        <thead class="thead-primary">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
       <tbody>
         
        </tbody>
      </table>
    </div>
  </div>
</section>
<!-- Enter Event Modal -->
<div class="modal fade" id="addApplication" tabindex="-1" aria-labelledby="modal_event_type" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal_event_type">Add Event Type</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array("class" => "manage_app"))?>
	    <div class="modal-body">
	      <div class="form-group">
	          <label>Name</label>  
	          <input type="text" name="appname" class="form-control" placeholder="Enter Application Name" autocomplete="off">
            <input type="hidden" name="id">
	      </div>
	    </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>
<?php elseif($type == 2) :  ?>
<section class="p-2">
  <div class="container-fluid">
  	<div class="mb-5">
	      <ul class="nav nav-tabs">
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('setting/application')?>">Application</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?=base_url('setting/motsid_app')?>">MOTSID Application</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('setting/category')?>">Compliance Category</a>
          </li>
	      </ul>
	    <button class="btn btn-primary float-end btn_margin btn-sm" data-bs-toggle="modal" data-bs-target="#addmotisd" style="margin-top: -2.25rem !important;">Add MOTSID</button>
    </div>
				<div class="table-responsive">
					<table class="table table-striped dd motsid_dt">
						<thead class="thead-primary">
    						<tr>
      							<th scope="col">#</th>
      							<th scope="col">MOTSID</th>
                    <th scope="col">Application</th>
      							<th scope="col">Status</th>
      							<th scope="col">Action</th>
    						</tr>
  						</thead>
  						<tbody>
    						
  						</tbody>
					</table>
				</div>
		</div>
	</section>
	<!-- Enter Event Modal -->
<div class="modal fade" id="addmotisd" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add MOTSID</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array("class"=>'manage_motsid'))?>
        <div class="modal-body">
          <div class="mb-2">
            <label>MOTSID</label>  
            <input type="text" name="motsid" class="form-control" placeholder="Enter MOTSID" autocomplete="off">
          </div>
          <div class="mb-2">
            <label>Application</label>  
            <input type="text" name="appname" class="form-control" placeholder="Enter Application" autocomplete="off">
          </div>
          <input type="hidden" name="id">
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>
<?php elseif($type == 3) : ?>
<section class="p-2">
  <div class="container-fluid">
    <div class="mb-5">
      <ul class="nav nav-tabs">
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('setting/application')?>">Application</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?=base_url('setting/motsid_app')?>">MOTSID Application</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="<?=base_url('setting/category')?>">Compliance Category</a>
          </li>
      </ul>
      <button class="btn btn-primary float-end btn_margin btn-sm" data-bs-toggle="modal" data-bs-target="#addcategory" style="margin-top: -2.25rem !important;">Add Category</button>
    </div>
    <div class="table-responsive">
      <table class="table table-striped dd category_datatable">
        <thead class="thead-primary">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
       <tbody>
         
        </tbody>
      </table>
    </div>
  </div>
</section>
<!-- Enter Event Modal -->
<div class="modal fade" id="addcategory" tabindex="-1" aria-labelledby="modal_event_type" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal_event_type">Add Category</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array("class" => "manage_category"))?>
      <div class="modal-body">
        <div class="form-group">
            <label>Name</label>  
            <input type="text" name="category" class="form-control" placeholder="Enter Application Name" autocomplete="off">
            <input type="hidden" name="id">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>

<?php elseif($type == 5) :  ?>
<section class="p-2">
  <div class="container-fluid">
    <div class="mb-5">
      <h4 class="flaot-start">Manage User</h4>
      <button class="btn btn-primary me-md-2 float-end" type="button" data-bs-toggle="modal" data-bs-target="#addusersmodal" style="margin-top: -2.25rem !important;">Add User</button>
      <hr>
    </div>

    <div class="table-responsive">
      <table class="table table-striped users_dt">
        <thead class="thead-primary">
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Username</th>
            <th scope="col">Mobile</th>
            <th scope="col">Email</th>
            <th scope="col">Created on</th>
            <th scope="col">Status</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          
        </tbody>
      </table>
    </div>
  </div>
</section>
<!-- Enter User Modal -->
<div class="modal fade" id="addusersmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array('class' => 'manage_user'))?>
        <div class="modal-body">
          <div class="col-md-12">
            <label for="Name" class="form-label">Name</label>
            <input type="text" class="form-control" id="Name" name="lname">
          </div>
          <div class="col-md-12">
            <label for="inputlname" class="form-label">UserName</label>
            <input type="text" class="form-control" id="inputlname" name="username">
          </div>
          <div class="col-12">
            <label for="inputmob" class="form-label">Mobile</label>
            <input type="tel" class="form-control" id="inputmob" name="mobile">
          </div>
          <div class="col-12">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email">
          </div>
          <div class="col-12">
            <label for="pwd" class="form-label">Password</label>
            <input type="password" class="form-control" id="pwd" placeholder="" name="pwd">
          </div>
          <div class="col-12">
            <label for="confirm_pwd" class="form-label">Confirm Password</label>
            <input type="password" class="form-control" id="confirm_pwd" placeholder="" name="cpwd">
          </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>


<!-- Update User Modal -->
<div class="modal fade" id="editusersModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update User</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array('class' => 'manage_user'))?>
        <div class="modal-body">
          <div class="col-md-12">
            <label for="Name" class="form-label">Name</label>
            <input type="text" class="form-control" id="Name" name="lname">
          </div>
          <div class="col-md-12">
            <label for="inputlname" class="form-label">UserName</label>
            <input type="text" class="form-control" id="inputlname" name="username">
          </div>
          <input type="hidden" name="id">
          <div class="col-12">
            <label for="inputmob" class="form-label">Mobile</label>
            <input type="tel" class="form-control" id="inputmob" name="mobile">
          </div>
          <div class="col-12">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email">
          </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>

<!-- Update User Modal -->
<div class="modal fade" id="change_user_password" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Reset Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array('class' => 'update_user_password'))?>
        <div class="modal-body">
          <div class="col-12">
             <input type="hidden" name="id">
            <label for="_pwd" class="form-label">Enter Password</label>
            <input type="password" class="form-control" id="_pwd" placeholder="" name="pwd">
          </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>

<!-- Update User Modal -->
<div class="modal fade" id="delete_user_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Reset Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <?=form_open('',array('class' => 'delete_user'))?>
        <div class="modal-body">
          <div class="col-12">
            <h5 class="text-danger">Are you sure you want to Delete this user (<span class="custordlemar"></span>) ?</h5>
            <input type="hidden" name="id">
          </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Delete</button>
      </div>
      <?=form_close()?>
    </div>
  </div>
</div>
<?php endif; ?>
