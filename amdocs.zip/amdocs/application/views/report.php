<section class="p-2">
  <div class="container">

    <h3>Reports</h3>
    <hr>

    <div class="row">
      
      <div class="col-6 mb-3">
        <div class="card p-5">
          <button class="btn btn-primary">Generate Tracker Report</button>
        </div>
      </div>
      <div class="col-6 mb-3">
        <div class="card p-5">
          <button class="btn btn-primary">Generate Compliance Report</button>
        </div>
      </div>

    </div>

  </div>
</section>