
<div class="container-fluid px-4">
    <div class="row mt-2">
       <div class="col-md-6">
          <a href="<?=base_url('tracker')?>" class="text-decoration-none">
           <div class="card mx-auto text-white bg-dark mb-3" style="max-width: 18rem;">
              <div style="padding: 0.1em;text-align: center;">
                <h5 class=""><i class="fas fa-book"></i> Tracker</h5>
              </div>
           </div>
          </a>
       </div>
       <div class="col-md-6 ">
        <a href="<?=base_url('compliance')?>" class="text-decoration-none">
           <div class="card mx-auto text-white bg-dark mb-3" style="max-width: 18rem;">
              <div style="padding: 0.1em;text-align: center;">
                <h5 class=""><i class="fas fa-book"></i> Compliance </h5>
              </div>
           </div>
        </a>
       </div>
    </div>
</div>