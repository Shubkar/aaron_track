# CHANGELOG

## v1.0.1

- Remove unneeded thead rule
- Remove `.navbar` display: none rule. Instead users can add `.d-print-none` class to navbar if desired.

## v1.0.0

- Initial Release
