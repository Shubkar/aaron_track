# Contributing

We are happy to accept contributions from the community to improve this project.

## Contribution Guidelines

- Use a [EditorConfig](https://editorconfig.org) plugin for consistent spacing and code formatting
